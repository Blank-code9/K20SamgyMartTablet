<?php 
include 'config.php';

if(isset($_GET['order'])){
    $order = $_GET['order'];
    $update = mysqli_query($con, "UPDATE orders SET status = '1' WHERE order_no = '$order'");
    if($update){
        echo "<script>alert('Order is ready')</script>";
        echo "<script>window.location.href='index.php'</script>";
    } else {
        echo "<script>alert('Failed to update order')</script>";
        echo "<script>window.location.href='index.php'</script>";
    }
    
}
?>